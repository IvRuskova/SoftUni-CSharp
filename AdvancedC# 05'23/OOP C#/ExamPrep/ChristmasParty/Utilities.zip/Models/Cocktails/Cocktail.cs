﻿using ChristmasPastryShop.Models.Cocktails.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Models.Cocktails
{
    public abstract class Cocktail : ICocktail
    {
        public string Name => throw new NotImplementedException();

        public string Size => throw new NotImplementedException();

        public double Price => throw new NotImplementedException();
    }
}
