﻿using ChristmasPastryShop.Models.Delicacies.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Models.Delicacies
{
    public abstract class Delicacy : IDelicacy
    {
        public string Name => throw new NotImplementedException();

        public double Price => throw new NotImplementedException();
    }
}
