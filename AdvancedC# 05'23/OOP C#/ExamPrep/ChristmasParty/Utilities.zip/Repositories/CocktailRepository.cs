﻿using ChristmasPastryShop.Models.Cocktails.Contracts;
using ChristmasPastryShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Repositories
{
    public class CocktailRepository : IRepository<ICocktail>
    {
        public IReadOnlyCollection<ICocktail> Models => throw new NotImplementedException();

        public void AddModel(ICocktail model)
        {
            throw new NotImplementedException();
        }
    }
}
