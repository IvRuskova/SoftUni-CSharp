﻿using ChristmasPastryShop.Models.Delicacies.Contracts;
using ChristmasPastryShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Repositories
{
    public class DelicacyRepository : IRepository<IDelicacy>
    {
        public IReadOnlyCollection<IDelicacy> Models => throw new NotImplementedException();

        public void AddModel(IDelicacy model)
        {
            throw new NotImplementedException();
        }
    }
}
