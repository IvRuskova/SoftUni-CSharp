﻿using ChristmasPastryShop.Models.Booths.Contracts;
using ChristmasPastryShop.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Repositories
{
    public class BoothRepository : IRepository<IBooth>
    {
        public IReadOnlyCollection<IBooth> Models => throw new NotImplementedException();

        public void AddModel(IBooth model)
        {
            throw new NotImplementedException();
        }
    }
}
