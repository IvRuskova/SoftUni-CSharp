﻿using WildFarm.Models.Interfaces;

namespace WildFarm.Models.Foods;

public class Vegetable : Food
{
    //Constructor
    public Vegetable(int quantity) : base(quantity) { }
}