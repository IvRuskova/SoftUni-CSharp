﻿namespace WildFarm.Models.Interfaces;

public interface IMammal : IAnimal
{
    //Properties
    public string LivingRegion { get; }
}