﻿namespace WildFarm.Models.Interfaces;

public interface IBird : IAnimal
{
    //Properties
    public double WingSize { get; }
}