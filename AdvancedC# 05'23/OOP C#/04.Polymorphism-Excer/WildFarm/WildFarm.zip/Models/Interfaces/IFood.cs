﻿namespace WildFarm.Models.Interfaces;

public interface IFood
{
    //Properties
    public int Quantity { get; }
}