﻿namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string username, int lavel) : base(username, lavel)
        {
        }
    }

}