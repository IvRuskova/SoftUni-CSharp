﻿namespace PlayersAndMonsters
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string username, int lavel) : base(username, lavel)
        {
        }
    }
}