﻿namespace PlayersAndMonsters
{
    public class Knight : Hero
    {
        public Knight(string username, int lavel) : base(username, lavel)
        {
        }
    }

}