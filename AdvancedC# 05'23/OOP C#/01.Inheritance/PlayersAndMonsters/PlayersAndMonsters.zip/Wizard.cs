﻿namespace PlayersAndMonsters
{
    public class Wizard : Hero
    {
        public Wizard(string username, int lavel) : base(username, lavel)
        {
        }
    }

}