﻿namespace PlayersAndMonsters
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string username, int lavel) : base(username, lavel)
        {
        }
    }
}